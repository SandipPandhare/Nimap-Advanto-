package com.example.Nimap_Advanto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NimapAdvantoApplicationTests {

	@Test
	void contextLoads() {
	}

}
